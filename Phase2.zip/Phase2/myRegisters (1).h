
#include <bits/stdc++.h>
using namespace std;
//IR holding Instructions and PC contains Memory location where the Instruction is present
class Registers
{

public:
    int IR;
    vector<int> reg; // all 32 registers
    Registers()
    {
        reg.assign(32, 0);
        IR = 0;
        reg[4] = 0x00000000;
        reg[2] = 0x7ffffff0;
        reg[3] = 0x10000000;
        reg[5] = 0x00000000;
    }

    int ReadReg()
    {
        return IR;  // reading Instruction
    }

    

   
    void WriteReg(int WriteVal, bool WriteReg)  // to write instruction in Registers
    {
        if (WriteReg)
        {
            IR = WriteVal;
        }
    }

    int ReadGlobalReg(int RegNumber)  // reading register value
    {
        if (RegNumber < 0 || RegNumber > 31)
        {
            throw "Invalid register number!";
        }
        else if (RegNumber == 0)
        {
            return 0;
        }
        int val = reg[RegNumber];
        cout << "Reading " << val << " from x" << RegNumber << endl;
        return val;
    }
     void WriteGlobalReg(int RegNumber, bool RegWrite, int WriteVal)  // function to write value in Registers
    {   
        if (RegNumber < 0 || RegNumber > 31)
        {
            throw "Invalid register number!";
        }
        else if (WriteVal >= pow(2,31)|| WriteVal < -pow(2,31))
        {
            throw "Value out of range!";
        }
        else if (RegNumber == 0 || !RegWrite)
        {
            return;
        }
        cout<<"Stage5: Write Back"<<endl;
        reg[RegNumber] = WriteVal;
        cout << "Written " << WriteVal << " in x" << RegNumber << endl;
    }
};
