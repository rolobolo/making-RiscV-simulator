#include <bits/stdc++.h>

using namespace std;

unordered_map<int, int> PC_INST; //  Map with key as program counter and value as instruction code
unordered_map<int, int> DATA; // dictionary with key as PC, value as instruction

void parser(string fileN)
{
    ifstream assembly_inst(fileN);
    if (!assembly_inst.is_open())  //check if input file provided
    {
        cout << "Error: cannot open file " << fileN << endl;
        return;
    }

    string line;
    int line_number = 0;
    bool is_instruction=false;
    while (getline(assembly_inst, line))
    {
        line_number++;

        // removes leading and trailing white spaces from each line 
        line.erase(0, line.find_first_not_of(" \t\r\n"));
        line.erase(line.find_last_not_of(" \t\r\n") + 1);

        

        if (line == "~data") {
            is_instruction = false;
            continue;
        }
        if (line == "~text") {
            is_instruction = true;
            continue;
        }

        // ignore lines starting with #
        if (line.empty() || line[0] == '#')
        {
            continue;
        }

       
        string::size_type comment_pos = line.find('#');
        if (comment_pos != std::string::npos)
        {
            line.erase(comment_pos);
        }

        vector<string> tokens;

         // splitting the string into program counter and instruction
        istringstream iss(line);


        for (string token; iss >> token;)
        {
            tokens.push_back(token);
        }
// if after spliting token not equal to two print error
        if (tokens.size() != 2)
        {
            cout << "Line " << line_number << ": Invalid syntax" << std::endl;
            return;
        }

        
        string pc_str = tokens[0];
        string inst_str = tokens[1];
        int pc, inst;
 // converting pc_str and _inst_str to integer pc and inst
        try
        {
            pc = stoul(pc_str, nullptr, 0); // interpreted as base 10 or 16
        }
        catch (const exception &e)
        {
            cerr << "Line " << line_number << ";Invalid program counter (PC)" << endl;
            exit(EXIT_FAILURE);
        }
        try
        {
            inst = stoul(inst_str, nullptr, 0); // interpreted as base 10 or 16
        }
        catch (const exception &e)
        {
            cerr << "Line " << line_number << ";Invalid instruction format" << endl;
            exit(EXIT_FAILURE);
        }
        if (pc > 0xffffffff)
        {
            cerr << "Line " << line_number << ";PC out of range" << endl;
            exit(EXIT_FAILURE);
        }
        if (inst > 0xffffffff)
        {
            cerr << "Line " << line_number << ";Instruction word out of range" << endl;
            exit(EXIT_FAILURE);
        }
        
        if (is_instruction) {
            PC_INST[pc] = inst;
        }
        else {
            DATA[pc] = inst;
        }

        // TODO: implement processing of assembly_inst
        cout << pc << " " << inst << "\n";
    }

    assembly_inst.close();
}

