#include <bits/stdc++.h>
using namespace std;

class BAM
  { 
      
        // key as address, value as memory content. Memory byte addressable! Thus, every element stores a byte
    

    public:
           int MAX_SIGNED_NUM = 0x7fffffff;
        int MIN_SIGNED_NUM = -0x80000000;
        int MAX_UNSIGNED_NUM = 0xffffffff;
        int MIN_UNSIGNED_NUM = 0x00000000;
        int MAX_PC = 0x7ffffffc;
         unordered_map<int, int> memory;

         
    unsigned int GetUnsigned(int base_address, int numBytes)
       { int data_value=0;
        for(int byte1=0; byte1<numBytes; byte1++ )
          {  if ((base_address + byte1 < MIN_UNSIGNED_NUM) || (base_address + byte1 > MAX_SIGNED_NUM)) // check if the address lies in range of data_value segment or not
                throw out_of_range("\033[1;31mAddress is not in range of data_value segment\033[0m");
              if(memory.find(base_address+byte1)!=memory.end())  
                data_value+= memory[base_address + byte1] << (byte1 * 8);
        }
        return data_value;}

    int GetSigned(int base_address, int numBytes)
       { if(numBytes==3)
            throw runtime_error("\033[1;31mInstruction not supported\033[0m");
        int  data_value=0;
        for(int byte1=0; byte1<numBytes;byte1++) //different number of bytes need to be accessed based on the command, ld , lw etc.
            {if ((base_address + byte1 < MIN_UNSIGNED_NUM) || (base_address + byte1 > MAX_SIGNED_NUM)) // check if the address lies in range of data_value segment or not
                 throw out_of_range("\033[1;31mAddress is not in range of data_value segment\033[0m");
               if(memory.find(base_address+byte1)!=memory.end())  
               data_value+=memory[base_address + byte1] << (byte1 * 8);
               }
        //conversion to signed value
        int  ms_mask = 0; // to get MSB
        int unsigned_num_mask=0; // to get all bits except MSB
        if(numBytes==1)
           { ms_mask=0x80;
            unsigned_num_mask=0x7f;}
        else if(numBytes==2)
            {ms_mask=0x8000;
            unsigned_num_mask=0x7fff;}
        else if(numBytes==4)
            {ms_mask=0x80000000;
            unsigned_num_mask=0x7fffffff;}
        
        data_value = (data_value & ms_mask) ? (data_value | ~unsigned_num_mask) : (data_value & unsigned_num_mask);
        return data_value;}

    void WriteValue(int base_address, int numBytes, int write_val) //can take both signed/unsigned value
       { int v=write_val;
        for(int byte1=0; byte1<numBytes;byte1++) //loop over every byte in the instruction, extract it and store it in little-endian format
            {int byte=v & 0x000000ff ;// bitmask to extract LS byte
            if ((base_address+byte1>MAX_SIGNED_NUM) ||( base_address+byte1<MIN_UNSIGNED_NUM))
                throw runtime_error("\033[1;31mMemory address out of range! Segmentation fault(core dumped)\033[0m");
            memory[base_address+byte1]=byte;
            v=v>>8 ;// bitwise right shift

       }
       }
       };
class ProcessorMem
{

    
    
public:
  static const int MAX_SIGNED_NUM = 0x7fffffff;
    static const int MIN_SIGNED_NUM = -0x80000000;
    static const int MAX_UNSIGNED_NUM = 0xffffffff;
    static const  int MIN_UNSIGNED_NUM = 0x00000000;
    static const int MAX_PC = 0x7ffffffc;
   int mem_add_reg=0; // Memory address register
   int mem_add_reg_pc=0;
    int mem_data_reg=0;
    int IRout=0;
    bool take_from_rm=false;
    BAM memory_data_module;
    BAM memory_text_module;
   

    void Initialise( unordered_map<int,int> PC_INST, unordered_map<int,int> DATA) // loads instruction to memory before execution of program
      {   for (auto addr: PC_INST)  //loop over every instruction
           {memory_text_module.WriteValue(addr.first,4,addr.second);}
           for (auto addr: DATA)  //loop over every data
           {memory_data_module.WriteValue(addr.first,4,addr.second);}
           cout<<"\033[92mProgram and data loaded to memory successfully\033[0m"<<endl;}

    int Load(int PC)
        {if (PC%4!=0) // PC must always be a multiple of 4, word alignment!
            {throw runtime_error("\033[1;31mInstruction not word aligned\033[0m");}
        else if (PC<MIN_UNSIGNED_NUM or PC>MAX_PC) // PC should be in a valid range
             {throw runtime_error("\033[1;31mPC out of range!!\033[0m");}
         mem_add_reg_pc=PC;
        int instruction=memory_text_module.GetUnsigned(mem_add_reg_pc,4);
         IRout=instruction;
       //  mem_data_reg=instruction;
        cout << "\033[93mLoaded instruction from " <<"0x"<< hex << PC << hex << instruction<< "\033[0m" << endl;
        return instruction;}

    // If MEM_read==true, ReadMem is called.
    // If MEM_write==true, then WriteMem is called.
    //Else, no action
    int Access(bool MEM_read , bool MEM_write, int base_address, int byte_size, int w_reg)
        {if (MEM_read==1&& MEM_write==0)
            mem_data_reg=ReadMem(base_address,byte_size);
        else if (MEM_write==1 && MEM_read==0)
            { WriteMem(base_address,byte_size,w_reg);
             }
        else if (MEM_read==0 && MEM_write==0)
                 {mem_data_reg=0; }
        else if(MEM_read==1&&MEM_write==1) //may change in pipelining
            throw runtime_error("\033[1;31mInvalid control signal received\033[0m");
        return mem_data_reg;}


    int ReadMem(int base_address, int numBytes)
        {
            cout<<"Stage4: Memory Access for Read Op"<<endl;
            mem_add_reg = base_address;
         mem_data_reg=memory_data_module.GetSigned(mem_add_reg, numBytes);
          cout << "\033[93m Read "<< numBytes<<"from "<<"0x"<< hex << base_address <<"value ="<<mem_add_reg<< "\033[0m" << endl;
         return mem_data_reg;}

     void WriteMem(int base_address, int byte_size, int w_reg)   //writes data_value in w_reg to address given by base_address
       {
         cout<<"Stage4: Memory Access for Write Op"<<endl; 
        mem_add_reg = base_address ;//mem_add_reg contains the base address to be written to
         mem_data_reg = w_reg ;//mem_data_reg contains data_value to be written at address given by mem_add_reg
         memory_data_module.WriteValue(base_address, byte_size, mem_data_reg);
        cout << "\033[93m Written "<<byte_size<<"at " <<"0x"<< hex << base_address << "value = "<<w_reg<<"\033[0m" << endl;
         }

};



