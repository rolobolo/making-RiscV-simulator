#include <iostream>
#include<bits/stdc++.h>
using namespace std;

#include "myRegisters.h"
#include "MemAccess.h"
#include "ControlCircuitCurrent.h"
#include "InstAddress.h"
#include "myALU.h"
#include "Buffers.h"
#include "Hazard.h"

#define MAX_SIGNED_NUM 0x7fffffff
#define MIN_SIGNED_NUM -0x80000000
#define MAX_UNSIGNED_NUM 0xffffffff
#define MIN_UNSIGNED_NUM 0x00000000

Registers registers;
ProcessorMem memory;
ControlModule control_module;
ALU ALUmodule;
IAG IAGmodule;
BTB_entry BTB_en;
Buffers buffer;
HazardUnit hazard_module;

// Muxes
int MuxAout = 0; // input 1 of ALU
int MuxBout = 0; // input 2 of ALU
int MuxYout = 0; // output of MuxY

class ControlBooleans {

public:
    bool MtoEtoRA = false; // booleans to indicate data forwarding in the end of the same cycle, then set it to false
    bool MtoEtoRB = false;
    bool EtoEtoRA = false;
    bool EtoEtoRB = false;
    bool MtoM = false; // this is always to mem_data_reg(rs2)
    bool decode_stall = false;
    bool fetch_stall = false;
    bool execute_stall = false;
    bool branch_prediction = false;
    bool global_terminate = true;
    int control_hazard_cnt = 0;
    int load_store = 0;
    int total_inst = 0;
    int ALU_ins_cnt = 0;
    int control_inst = 0;
    int bubbles = 0;
    int branch_mis_cnt = 0;
    int data_stall = 0;
    int control_stall = 0;
};

ControlBooleans forward_bool;

void fetch(int stage, int clock) {
    // to do here
    // if terminate==1, return
    control_module.StateUpdate(0);
    if(control_module.terminate) {
        return;
    }
    if(!control_module.fetch_deque_signal()) {
        return;
    }
    // operation queue will be used in the buffer update stage, not here.
    // fetch the instruction using the value in PC
    forward_bool.global_terminate = false;
    buffer.IRbuffer = memory.Load(IAGmodule.PC); // update IR buffer
    forward_bool.branch_prediction = IAGmodule.BTB_check(IAGmodule.PC);// update branch prediction
    BTB_entry target_obj;
    if(forward_bool.branch_prediction) {
        target_obj = IAGmodule.BTB[IAGmodule.PC];
        buffer.Fetch_output_PC_temp = target_obj.target_address;
        cout << "Fetch- Branch prediction." << buffer.Fetch_output_PC_temp << " predicted" << std::endl;
    }
    else {
        buffer.Fetch_output_PC_temp = IAGmodule.PC + 4;
    }
    // compare it to BTB to check if that is a branch/jump. If it is, update PC to the target.
}

void decode(int stage, int clock) {

    // if terminate==1, return
    // check the operation queue. If empty, then operate. Else, don't operate and pop.
    if (control_module.terminate) {
        hazard_module.add_table_inst(0x11, 0, 0, 0, 0);
        return;
    }
    forward_bool.global_terminate = false;
    cout << "Decode Stage" << endl;
    //mtod = false;
    if (!control_module.decode_deque_signal()) {
        // decode stage is inactive. Perform other tasks
        if (control_module.MtoEcode == 0) { // decode init
            forward_bool.decode_stall = true;
            return;
        }
        if (control_module.MtoEcode == -2) { // branch misprediction
            forward_bool.fetch_stall = false;
            forward_bool.decode_stall = true;
            return;
        }
        // if control_module.MtoEcode == -1:
        //     mtod = true;
        //     return; // M to D stall
        forward_bool.decode_stall = true;
        forward_bool.fetch_stall = true;
        if (control_module.MtoEcode == 21) {
            forward_bool.data_stall += 1;
            forward_bool.execute_stall = true;
            forward_bool.MtoEtoRA = true;
            return;
        }
        if (control_module.MtoEcode == 22) {
            forward_bool.data_stall += 1;
            forward_bool.execute_stall = true;
            forward_bool.MtoEtoRB = true;
            return;
        }
        if (control_module.MtoEcode == 23) {
            forward_bool.data_stall += 1;
            forward_bool.execute_stall = true;
            forward_bool.MtoEtoRA = true;
            forward_bool.MtoEtoRB = true;
            return;
        }
    }

    // decode the instruction first in the IR
    // control_module.decode(registers.ReadReg(), IAGmodule.PC);
    control_module.decode(registers.ReadReg(), buffer.Decode_input_PC);
    if (control_module.terminate) {
        return;
    }
    // check for hazards using the hazard table.
    vector<int> hazard_code = hazard_module.decision_maker(control_module.opcode, control_module.funct3, control_module.rs1, control_module.rs2, control_module.rd, 1); // 1 for forwarding
    // if hazard, perform corrective measures here and return. Do not execute further code
    bool to_return = false;
    if (hazard_code[1] != -1 || hazard_code[0] != -1) { // data hazard!
        cout << "Hazard-" << buffer.Decode_input_PC << endl;
        // code here for data hazard
        // first handling hazard[0] then hazard[1]
        if (hazard_code[1] != -1) {
            if (hazard_code[1] == 404) { // 1 decode stall
                cout << "Decode stall" << endl;
                control_module.execute_set_NOP();
                control_module.memory_set_NOP();
                control_module.register_set_NOP();
                forward_bool.decode_stall = true;
                forward_bool.fetch_stall = true;
                forward_bool.data_stall += 1;
                to_return = true;
            } else if (hazard_code[1] == 505) { // 2 decode stall
                cout << "Decode stall" << endl;
                control_module.execute_set_NOP();
                control_module.memory_set_NOP();
                control_module.register_set_NOP();
                forward_bool.decode_stall = true;
                forward_bool.fetch_stall = true;
                forward_bool.data_stall += 1;
                to_return = true;
            }
            if (hazard_code[1] == 310) {
                control_module.mem_ForwardingQueue.push_front(0); // set boolean to true in memory module
                cout << "MyoM, EtoEtoRA" << endl;
                forward_bool.EtoEtoRA = true;
            } else if (hazard_code[1] == 0) {
                control_module.mem_ForwardingQueue.push_front(0); // set boolean to true in memory module
            } else if (hazard_code[1] == 11) {
                cout << "MtoEtoRA" << endl;
                forward_bool.MtoEtoRA = true;
            } else if (hazard_code[1] == 12) {
                forward_bool.MtoEtoRB = true;
            } else if (hazard_code[1] == 13) {
                forward_bool.MtoEtoRA = true;
                forward_bool.MtoEtoRB = true;
            } else if (hazard_code[1] == 21) {
                control_module.decode_operation.push_front(21);
                // push 1 nop and the decoded instruction in the queues
                control_module.execute_set_NOP();
                control_module.memory_set_NOP();
                control_module.register_set_NOP();
            } else if (hazard_code[1] == 22) {
                control_module.decode_operation.push_front(22);
                control_module.execute_set_NOP();
                control_module.memory_set_NOP();
                control_module.register_set_NOP();
            } else if (hazard_code[1] == 23) {
                control_module.decode_operation.push_front(23);
                //control_module.decode_set_NOP() // edit
                // push 1 nop and the decoded instruction in the queues
                control_module.execute_set_NOP();
                control_module.memory_set_NOP();
                control_module.register_set_NOP();
            } else if (hazard_code[1] == 31) {
                cout << "EtoEtoRA\n";
                forward_bool.EtoEtoRA = true;
            } else if (hazard_code[1] == 32) {
               cout << "EtoEtoRB\n";
                forward_bool.EtoEtoRB = true;
            } else if (hazard_code[1] == 33) {
                cout << "EtoEtoRB RA\n";
                forward_bool.EtoEtoRA = true;
                forward_bool.EtoEtoRB = true;
            }
        }
        if (hazard_code[0] != -1) {
            if (hazard_code[0] == 404) {
                cout << "Decode stall\n";
                control_module.execute_set_NOP();
                control_module.memory_set_NOP();
                control_module.register_set_NOP();
                forward_bool.decode_stall = true;
                forward_bool.fetch_stall = true;
                forward_bool.data_stall += 1;
                to_return = true;
            } else if (hazard_code[0] == 505) {
                cout << "Decode stall\n";
                control_module.execute_set_NOP();
                control_module.memory_set_NOP();
                control_module.register_set_NOP();
                forward_bool.decode_stall = true;
                forward_bool.fetch_stall = true;
                forward_bool.data_stall += 1;
                to_return = true;
            } else if (hazard_code[0] == 310) {
                control_module.mem_ForwardingQueue.push_back(0);
                cout << "MtoM, EtoEtoRA\n";
                forward_bool.EtoEtoRA = true;
            } else if (hazard_code[0] == 0) {
                control_module.mem_ForwardingQueue.push_back(0);
            } else if (hazard_code[0] == 11) {
                cout << "MtoEtoRA\n";
                forward_bool.MtoEtoRA = true;
            } else if (hazard_code[0] == 12) {
                forward_bool.MtoEtoRB = true;
            } else if (hazard_code[0] == 13) {
                forward_bool.MtoEtoRA = true;
                forward_bool.MtoEtoRB = true;
            } else if (hazard_code[0] == 21) {
                control_module.decode_operation.push_back(21);
                control_module.execute_set_NOP();
                control_module.memory_set_NOP();
                control_module.register_set_NOP();
            } else if (hazard_code[0] == 22) {
                control_module.decode_operation.push_back(22);
                control_module.execute_set_NOP();
                control_module.memory_set_NOP();
                control_module.register_set_NOP();
            } else if (hazard_code[0] == 23) {
                control_module.decode_operation.push_back(23);
                control_module.execute_set_NOP();
                control_module.memory_set_NOP();
                control_module.register_set_NOP();
            } else if (hazard_code[0] == 31) {
                forward_bool.EtoEtoRA = true;
            } else if (hazard_code[0] == 32) {
                forward_bool.EtoEtoRB = true;
            } else if (hazard_code[0] == 33) {
                forward_bool.EtoEtoRA = true;
                forward_bool.EtoEtoRB = true;
            }
        }
    }
    if (to_return) {
        return;
    }

    int MuxAout = 0;
    int MuxBout = 0;
    if (control_module.MuxBSelect == 0) {
        MuxBout = registers.ReadGlobalReg(control_module.rs2);
    } else if (control_module.MuxBSelect == 1) {
        MuxBout = control_module.imm;
    }
    if (control_module.MuxASelect == 0) {
        MuxAout = registers.ReadGlobalReg(control_module.rs1);
    } else if (control_module.MuxASelect == 1) {
        MuxAout = buffer.Decode_input_PC;
    }
    buffer.RAtemp = MuxAout;
    buffer.RBtemp = MuxBout;
    buffer.RMtemp = registers.ReadGlobalReg(control_module.rs2);
    control_module.RM_placeholder = buffer.RMtemp;
    control_module.RA_placeholder = buffer.Decode_input_PC + 4; // return address
    ALUmodule.outputBool = 0;
    if (control_module.branch) {
        ALUmodule.ALUexecute(control_module.ALUOp, control_module.ALUcontrol, buffer.RAtemp, buffer.RBtemp);
    }
    IAGmodule.PC_buffer = buffer.Decode_input_PC;
    control_module.BranchUpdate(ALUmodule.outputBool);
    IAGmodule.PCset(buffer.RAtemp, control_module.MuxPCSelect);
    IAGmodule.SetOffset(control_module.imm);
    IAGmodule.PCUpdate(control_module.MuxINCSelect);
    //cout << "\t\t\tiag pc buffer " << hex << IAGmodule.PC_buffer << endl;
    //buffer.Decode_output_PC_temp = IAGmodule.PC_buffer;
    // use branch prediction from the buffer
    //cout << "RAtemp-" << buffer.RAtemp << " RBtemp-" << buffer.RBtemp << " RA-" << buffer.RA << " RB-" << buffer.RB << endl;
    //cout << "\t\t\tRA placeholder- " << control_module.RA_placeholder << endl;
    control_module.branch_misprediction = buffer.Decode_input_branch_prediction ^ (control_module.jump || (control_module.branch && ALUmodule.outputBool));

    if (buffer.Decode_input_branch_prediction == 0 && (control_module.opcode == 111)) {
        cout << "BTB entry created. " << IAGmodule.PC_buffer << endl;
        IAGmodule.BTB_insert(buffer.Decode_input_PC, IAGmodule.PC_buffer, 1);
    }

    if (buffer.Decode_input_branch_prediction == 0 && control_module.branch) {
        cout << "BTB entry created. " << buffer.Decode_input_PC + control_module.imm << endl;
        IAGmodule.BTB_insert(buffer.Decode_input_PC, buffer.Decode_input_PC + control_module.imm, 1);
    }

    if (control_module.branch_misprediction) {
        // code here for handling branch misprediction
        cout << "Branch misprediction" << endl;
        forward_bool.branch_mis_cnt += 1;
        forward_bool.control_stall += 1;
        forward_bool.control_hazard_cnt += 1;
        control_module.decode_operation.push_back(-2); // -2 is the code to indicate a branch misprediction and the decode unit does not have to operate
        forward_bool.total_inst += 1;
        if (control_module.jump || control_module.branch) {
            forward_bool.control_inst += 1;
        }
        hazard_module.add_inst(control_module.opcode, control_module.funct3, control_module.rs1, control_module.rs2, control_module.rd);
        hazard_module.add_table_inst(control_module.opcode, control_module.funct3, control_module.rs1, control_module.rs2, control_module.rd); // end of prog
        buffer.Decode_output_PC_temp = IAGmodule.PC_buffer;
        control_module.execute_set_operate();
        control_module.memory_set_operate();
        control_module.register_set_operate();
        control_module.execute_set_NOP();
        control_module.memory_set_NOP();
        control_module.register_set_NOP();
        return;
    }

    // push NOPs whenever needed, call the exexute_set_NOP etc methods is ControlModule according to hazard code
    // if misprediction, perform corrective measures here and return if necessary follow steps given in documentation to resolve the hazard by stalling/data forwarding.
    // in case of jalr, compute effective address and update decode_output_PC_temp by that value.
    // if all good, push the decoded the signals into the queues.
    forward_bool.total_inst += 1;
    if (control_module.jump || control_module.branch) {
        forward_bool.control_inst += 1;
    }
    hazard_module.add_inst(control_module.opcode, control_module.funct3, control_module.rs1, control_module.rs2, control_module.rd);
    hazard_module.add_table_inst(control_module.opcode, control_module.funct3, control_module.rs1, control_module.rs2, control_module.rd); // end of prog
    control_module.execute_set_operate();
    control_module.memory_set_operate();
    control_module.register_set_operate();

}

void execute(int stage, int clock) { // ALU
    // dequeue from the control signals. Check if we need to operate or not
    if (!control_module.execute_deque_signal()) { // this function returns False if memory is in NOP. Also, all control_module.ALUop, etc are updated to 0 in case of NOP, or correct value if OP
        // perform other tasks and return
        return;
    }
    forward_bool.global_terminate = false;
    cout << "Execute Stage" << endl;
    // can use control_module.ALUop etc directly to use as arguments to ALU.
    //cout << "ALUcontrol-" << control_module.ALUcontrol << " ALUop-" << control_module.ALUOp << endl;
    if (control_module.ALUOp) {
        forward_bool.ALU_ins_cnt += 1;
    }
    ALUmodule.ALUexecute(control_module.ALUOp, control_module.ALUcontrol, buffer.getRA(), buffer.getRB());
    buffer.RZtemp = ALUmodule.output32;	//simple execution
    //cout << "clock- " << clock << " RZtemp-" << buffer.RZtemp << " ALUoutput-" << ALUmodule.output32 << endl;
}

void mem_access(int stage, int clock) {
    // dequeue from the control signals. Check if we need to operate or not
    if (!control_module.memory_deque_signal()) { // this function returns False if memory is in NOP. Also, all control_module.MemRead, etc are updated to 0 in case of NOP, or correct value if OP
        // perform other tasks and return
        return;
    }
    forward_bool.global_terminate = false;
    std::cout << "Memory Access\n";
    // acess memory and update temp memory buffers (RM_temp)
    // check forwarding
    if (memory.take_from_rm) {
        std::cout << "Taken from M\n";
        control_module.RM_placeholder = buffer.RM;
        memory.take_from_rm = false;
    }
    // std::cout << "memory- " << control_module.MemRead << " " << control_module.MemWrite << " " << std::hex << buffer.getRZ() << " " << control_module.BytesToAccess << " " << control_module.RM_placeholder << "\n";
    if (control_module.MemRead || control_module.MemWrite) {
        forward_bool.load_store++;
    }
    memory.Access(control_module.MemRead, control_module.MemWrite, buffer.getRZ(), control_module.BytesToAccess, control_module.RM_placeholder); // why RMtemp? RM is updated at the end of cycle
    // std::cout << "Memory mem_data_reg- " << memory.mem_data_reg << " Memory MAR- " << memory.MAR << "\n";
    if (control_module.mem_ForwardingQueue.size() != 0) {
        // check forwarding code
        // if MtoE
        control_module.MtoEcode = control_module.mem_ForwardingQueue.front(); // m to m forwarding
        control_module.mem_ForwardingQueue.pop_front();
        if (control_module.MtoEcode == 0) {
            forward_bool.MtoM = true;
            memory.take_from_rm = true;
        }
        else if (control_module.MtoEcode == 21) {
            forward_bool.MtoEtoRA = true;
            forward_bool.MtoEtoRB = false;
        }
        else if (control_module.MtoEcode == 22) {
            forward_bool.MtoEtoRB = true;
            forward_bool.MtoEtoRA = false;
        }
        else if (control_module.MtoEcode == 23) {
            forward_bool.MtoEtoRA = true;
            forward_bool.MtoEtoRB = true;
        }
    }
    // set RYtemp according to values and MuxY control
    // std::cout << "MuxYSelect " << control_module.MuxYSelect << "\n";
    if (control_module.MuxYSelect == 0) {
        // std::cout << "RZ to RY\n";
        buffer.RYtemp = buffer.getRZ();
    }
    else if (control_module.MuxYSelect == 1) {
        // std::cout << "mem_data_reg to RY " << memory.mem_data_reg << "\n";
        buffer.RYtemp = memory.mem_data_reg;
    }
    else if (control_module.MuxYSelect == 2) {
        // std::cout << "\t\tRY set to RA!! " << control_module.RA_placeholder << "\n";
        buffer.RYtemp = control_module.RA_placeholder;
    }
}

void reg_writeback(int stage, int clock) {
    if (!control_module.register_deque_signal()) {
        return;
    }
    forward_bool.global_terminate = false;
    cout << "RegisterWrite stage" << endl;
    registers.WriteGlobalReg(control_module.rd, control_module.RegWrite, buffer.getRY());
}

void buffer_update() {
    if (!forward_bool.fetch_stall) {
        registers.WriteReg(buffer.IRbuffer, 1);
        buffer.Decode_input_branch_prediction = forward_bool.branch_prediction;
        buffer.Decode_input_PC = IAGmodule.PC;
        if (!control_module.branch_misprediction) {
            cout << "PC updated by fetch " << buffer.Fetch_output_PC_temp << endl;
            IAGmodule.PC = buffer.Fetch_output_PC_temp;
        }
    }
    if (!forward_bool.decode_stall)
    {
        buffer.RA = buffer.RAtemp;
        buffer.RB = buffer.RBtemp;
        if (control_module.branch_misprediction)
        {
            cout << "PC updated by decode " << IAGmodule.PC_buffer << endl;
            IAGmodule.PC = IAGmodule.PC_buffer;
        }
    }
    if (!forward_bool.execute_stall)
    {
        buffer.RZ = buffer.RZtemp;
    }
    buffer.RY = buffer.RYtemp;
    if (forward_bool.MtoM)
    {
        buffer.RM = buffer.RY;
        forward_bool.MtoM = false;
    }
    if (forward_bool.MtoEtoRA)
    {
        buffer.RA = buffer.RY;
        forward_bool.MtoEtoRA = false;
    }
    if (forward_bool.MtoEtoRB)
    {
        buffer.RB = buffer.RY;
        forward_bool.MtoEtoRB = false;
    }
    if (forward_bool.EtoEtoRA)
    {
        cout << "E to E to RA" << endl;
        buffer.RA = buffer.RZ;
        forward_bool.EtoEtoRA = false;
    }
    if (forward_bool.EtoEtoRB)
    {
        buffer.RB = buffer.RZ;
        forward_bool.EtoEtoRB = false;
    }
    if (forward_bool.fetch_stall || forward_bool.decode_stall || forward_bool.execute_stall)
    {
        hazard_module.add_null();
    }
    forward_bool.fetch_stall = false;
    forward_bool.decode_stall = false;
    forward_bool.execute_stall = false;
    control_module.branch_misprediction = false;
}

void RunSim_fwd(int reg_print=1, int buffprint=1){
    int clock=1;
    while(true){
        cout << "\n\033[1;96mCycle " << clock << "\033[0m\n";
        forward_bool.global_terminate=true;
        reg_writeback(4, clock);
        mem_access(3,clock);
        execute(2,clock);
        cout << "Hazard Table:" << endl;
        hazard_module.print_table();
        decode(1,clock);
        fetch(0,clock);
        buffer_update();
        //cout << "PC" << IAGmodule.PC << " IR " << hex(registers.IR) << " RZ " << buffer.RZ << " RY " << buffer.RY << "\n###########################################\n" << endl;

        if (reg_print==1){
            cout << "Register file: " << endl;
            for (int i=0; i<32; i++){
                cout << "reg[" << i << "]= "<<hex<<registers.reg[i]<< " ";
                if (i%8==0 && i>0){
                    cout << endl;
                }
            }
        }
        cout << endl;
        if (buffprint==1){
            cout << "Pipeline buffers: " << endl;
            cout << "\033[1;96mPC: " << hex<< IAGmodule.PC << " IR: " << hex << registers.IR << " RZ: " << buffer.RZ << " RY: " << buffer.RY << "\nRA: " << buffer.RA << " RB: " << buffer.RB << " Decode-Input-PC: " << buffer.Decode_input_PC << "\nBranch predication buffer: " << buffer.Decode_input_branch_prediction << "\033[0m" << endl;
        }
        cout << "##################################################" << endl;
        if (forward_bool.global_terminate){
            cout << "Stats-" << endl;
            cout << "Stat1: Cycles: " << clock << endl;
            cout << "Stat2: Total Instructions: " << forward_bool.total_inst << endl;
            cout << "Stat3: CPI: " << clock/forward_bool.total_inst << endl;
            cout << "Stat4: Load/Store: " << forward_bool.load_store << endl;
            cout << "Stat5: ALU instructions: " << forward_bool.ALU_ins_cnt << endl;
            cout << "Stat6: Control instructions: " << forward_bool.control_inst << endl;
            cout << "Stat7: Bubbles: " << forward_bool.data_stall+forward_bool.control_stall << endl;
            cout << "Stat8: Total Data Hazards: " << hazard_module.count_data_hazards() << endl;
            cout << "Stat9: Total Control Hazards: " << forward_bool.control_hazard_cnt << endl;
            cout << "Stat10: Total branch mispredictions Hazards: " << forward_bool.branch_mis_cnt << endl;
            cout << "Stat11: Stall due to data hazard: " << forward_bool.data_stall << endl;
            cout << "Stat12: Stall due to control hazard: " << forward_bool.control_stall << endl;
            return;
        }
        clock=clock+1;
    }
}
