

// class and function definitions

#include <bits/stdc++.h>
#include <cstdlib>
#include "myParser.h"
#include "runRiscSim.h"


// class and function definitions


using namespace std;
string toHexa(int value)
{
    stringstream stream;
    stream << "0x" << setfill('0') << std::setw(8) << hex << value;
    return stream.str();
}

int main(int argc, char *argv[])
{
    if (argc == 1)
    {
        cout << "File name not supplied!" << endl;
        return 1;
    }

    parser(argv[1]); // supply input file name

    // program load
    memory.Initialise(PC_INST, DATA);

    // run the simulator
     RunRiscSim();

    ofstream Rfile("RegisterDump_non_pipeline.mc");

    for (int i = 0; i < 32; i++)
    {                               // for all 32 registers
        Rfile << "x" << i << " "; // print address of register
        if (registers.reg[i] >= 0)
        {
            string str = toHexa(registers.reg[i]);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            replace(str.begin(), str.end(), 'X', 'x');
            Rfile << str;
        }
        else
        {
            uint32_t reg = registers.reg[i] & 0xffffffff; // signed
            string str = toHexa(reg);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            replace(str.begin(), str.end(), 'X', 'x');
            Rfile << str;
        }
        Rfile << "\n";
    }

    Rfile.close();

    ofstream file_mem("MemoryDump_non_pipeline.mc");
    unordered_map<int, int> memory1 = memory.memory_data_module.memory;
    vector<int> lst;                                               
    vector<int> t_list;                                          
 file_mem <<"Data:"<<endl; 
    for (auto p : memory1)
    {
        lst.push_back(p.first);
    }
    sort(lst.begin(), lst.end());

    for (auto x : lst)
    {
        int temp = x - (x % 4); // storing base address in temp
        if (find(t_list.begin(), t_list.end(), temp) == t_list.end())
        { // if base address not present in temp_list , then append it
            t_list.push_back(temp);
        }
    }
    sort(t_list.begin(), t_list.end());
    for (auto i : t_list)
    {
        string str = toHexa(i);
        transform(str.begin(), str.end(), str.begin(), ::toupper);
        replace(str.begin(), str.end(), 'X', 'x');
        file_mem << str << " "; // printing base address
        if (memory1.find(i) != memory1.end())
        {
            string str = toHexa(memory1[i]);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            file_mem << str.substr(8) << " "; // if key in dictionary, print its data
        }
        else
        {
            file_mem << "00 ";
        }
        if (memory1.find(i + 1) != memory1.end())
        {
            string str = toHexa(memory1[i + 1]);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            file_mem << str.substr(8) << " ";
        }
        else
        {
            file_mem << "00 ";
        }
        if (memory1.find(i + 2) != memory1.end())
        {
            string str = toHexa(memory1[i + 2]);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            file_mem << str.substr(8) << " ";
        }
        else
        {
            file_mem << "00 ";
        }
        if (memory1.find(i + 3) != memory1.end())
        {
            string str = toHexa(memory1[i + 3]);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            file_mem << str.substr(8) << " ";
        }
        else
        {
            file_mem << "00  ";
        }
        file_mem << endl;
    }

file_mem <<"Text:"<<endl; 
     unordered_map<int, int> memory2 = memory.memory_text_module.memory;
                                          

    for (auto p : memory2)
    {
        lst.push_back(p.first);
    }
    sort(lst.begin(), lst.end());

    for (auto x : lst)
    {
        int temp = x - (x % 4); // storing base address in temp
        if (find(t_list.begin(), t_list.end(), temp) == t_list.end())
        { // if base address not present in temp_list , then append it
            t_list.push_back(temp);
        }
    }
    sort(t_list.begin(), t_list.end());
    for (auto i : t_list)
    {
        string str = toHexa(i);
        transform(str.begin(), str.end(), str.begin(), ::toupper);
        replace(str.begin(), str.end(), 'X', 'x');
        file_mem << str << " "; // printing base address
        if (memory2.find(i) != memory2.end())
        {
            string str = toHexa(memory2[i]);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            file_mem << str.substr(8) << " "; // if key in dictionary, print its data
        }
        else
        {
            file_mem << "00 ";
        }
        if (memory2.find(i + 1) != memory2.end())
        {
            string str = toHexa(memory2[i + 1]);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            file_mem << str.substr(8) << " ";
        }
        else
        {
            file_mem << "00 ";
        }
        if (memory2.find(i + 2) != memory2.end())
        {
            string str = toHexa(memory2[i + 2]);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            file_mem << str.substr(8) << " ";
        }
        else
        {
            file_mem << "00 ";
        }
        if (memory2.find(i + 3) != memory2.end())
        {
            string str = toHexa(memory2[i + 3]);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            file_mem << str.substr(8) << " ";
        }
        else
        {
            file_mem << "00  ";
        }
        file_mem << endl;
    }
    file_mem.close();
    cout << "\033[1;92m RegisterDump_non_pipeline.mc and MemoryDump_non_pipeline.mc ready!\033[0m" << std::endl;
    return 0;
}
