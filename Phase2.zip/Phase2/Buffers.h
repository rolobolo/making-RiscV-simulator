#include <bits/stdc++.h>
using namespace std;

class Buffers {

public:
    int RA = 0;
    int RB = 0;
    int RAtemp = 0;
    int RBtemp = 0;
    int RZ = 0;
    int RM = 0;
    int RMtemp = 0;
    int RY = 0;
    int RYtemp = 0;
    int RZtemp = 0;
    int IRbuffer = 0;
    int Fetch_output_PC_temp = 0;
    int Decode_output_PC_temp = 0;
    int Decode_input_PC = 0;
    bool Decode_input_branch_prediction = false;
    int R1=0;
    int R2 = 0;
    int R1temp = 0;
    int R2temp = 0;
    int Decode_PC_temp=0;
    int Fetch_PC_temp=0;

    int getR1() {
        return R1;
    }

    int getR2() {
        return R2;
    }

    int getR1temp() {
        return R1temp;
    }

    int getR2temp() {
        return R2temp;
    }

    int getRA() {
        return RA;
    }

    int getRB() {
        return RB;
    }

    int getRAtemp() {
        return RAtemp;
    }

    int getRBtemp() {
        return RBtemp;
    }

    int getRZ() {
        return RZ;
    }

    int getRM() {
        return RM;
    }

    int getRMtemp() {
        return RMtemp;
    }

    int getRY() {
        return RY;
    }

    int getFetch_PC_temp() {
        return Fetch_PC_temp;
    }

    int getDecode_PC_temp() {
        return Decode_PC_temp;
    }

    void setR1(int val, bool control_R1) {
        if (control_R1) {
            R1 = val;
        }
    }

    void setR2(int val, bool control_R2) {
        if (control_R2) {
            R2 = val;
        }
    }

    void setR1temp(int val, bool control_R1temp) {
        if (control_R1temp) {
            R1temp = val;
        }
    }

    void setR2temp(int val, bool control_R2temp) {
        if (control_R2temp) {
            R2temp = val;
        }
    }

    void setRA(int val, bool control_RA) {
        if (control_RA) {
            RA = val;
        }
    }

    void setRB(int val, bool control_RB) {
        if (control_RB) {
            RB = val;
        }
    }

    void setRAtemp(int val, bool control_RAtemp) {
        if (control_RAtemp) {
            RAtemp = val;
        }
    }

    void setRBtemp(int val, bool control_RBtemp) {
        if (control_RBtemp) {
            RBtemp = val;
        }
    }

    void setRZ(int val, bool control_RZ) {
        if (control_RZ) {
            RZ = val;
        }
    }

    void setRM(int val, bool control_RM) {
        if (control_RM) {
            RM = val;
        }
    }

    void setRMtemp(int val, bool control_RMtemp) {
        if (control_RMtemp) {
            RMtemp = val;
        }
    }

    void setRY(int val, bool control_RY) {
        if (control_RY) {
            RY = val;
        }
    }

    void setFetch_output_PC_temp(int val) {
        Fetch_output_PC_temp = val;
    }

    void setDecode_output_PC_temp(int val) {
        Decode_output_PC_temp = val;
    }

};

class Buffers_np {

private:
    int RA;
    int RZ;
    int RM;
    int RY;

public:
    Buffers_np() {
        RA = 0;
        RZ = 0;
        RM = 0;
        RY = 0;
    }
    int getRA() {
        return RA;
    }
    int getRZ() {
        return RZ;
    }
    int getRM() {
        return RM;
    }
    int getRY() {
        return RY;
    }
    void setRA(int val) {
        RA = val;
    }
    void setRZ(int val) {
        RZ = val;
    }
    void setRM(int val) {
        RM = val;
    }
    void setRY(int val) {
        RY = val;
    }
};
