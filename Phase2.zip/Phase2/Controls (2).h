// drishti2511
#include <bits/stdc++.h>
using namespace std;
#define fio                           \
    ios_base::sync_with_stdio(false); \
    cin.tie(NULL)
typedef long long ll;
#define lop(i, a, b) for (i = a; i < b; i++)
ll mod = 1e9 + 7;
#define max3(a, b, c) max(max((a), (b)), (c))
#define max4(a, b, c, d) max(max((a), (b)), max((c), (d)))
#define min3(a, b, c) min(min((a), (b)), (c))
#define min4(a, b, c, d) min(min((a), (b)), min((c), (d)))
#define all(v) (v).begin(), (v).end()
#define YES cout << "YES" << endl
#define NO cout << "NO" << endl
#define input(v, n) lop(i, 0, n) cin >> v[i]
#define take(x)       \
    for (auto &y : x) \
    cin >> y
#define show(x)           \
    for (auto y : x)      \
        cout << y << " "; \
    cout << endl
#define deb(x) cout << x << " "
// gcd func __gcd(m,n)
// g++ --std c++11 t4.cpp
// end of template

int MAX_SIGNED = 0x7fffffff;
int MIN_SIGNED = -0x80000000;
int MAX_UNSIGNED = 0xffffffff;
int MIN_UNSIGNED = 0x00000000;
int mask32 = 0x80000000;
int bit_0_to_31_mask = 0x7fffffff;

class ControlModule
{

public:
    int opcode = 0;
    int funct3 = 0;
    int funct7 = 0;
    int rd = 0;
    int rs1 = 0;
    int rs2 = 0;
    int imm = 0;
    bool isBranch = false;
    bool BranchTargetSet = false;
    int ResultSelect = 0;
    int ALUcontrol = 0;
    bool ALUOp = 0;
    bool RFWrite = false;
    bool RegWrite = 0;
    bool IRwrite = 0;
    bool PCwrite = 0;
    bool Op2Select = false;
    bool MemOp = false;
    bool MemRead = false;
    bool MemWrite = false;
    int BytesToAccess = 0; // memory access
    int MuxINCSelect = 0;  // to IAG, 0 for 4(sequential next), 1 for branch offset(imm)
    int MuxPCSelect = 1;   // to IAG, 0 for ra and 1 for normal PC
    int MuxYSelect = 0;    // present at output of ALU
    int MuxAselect = 0;
    bool branch = 0;    // signal to enforce checking output of ALU since branches are conditional
    bool jump = 0;      // for jump signals(see doc)
    int MuxBSelect = 0; // present at 2nd input of ALU
    int MuxASelect = 0;
    bool terminate = false;
    // arrays for storing opcodes declared as global vectors

    void StateUpdate(int stage)
    {
        // whether to change the value of PC and instruction in fetch stage
        if (stage == 2) // change
            PCwrite = 1;
        else
            PCwrite = 0;
        if (stage == 0)
            IRwrite = 1;
        else
            IRwrite = 0;
    }
    void SignalGenerator()
    {
        switch (opcode)
        {
        case 51:          // R-type
            ALUOp = 1;    // ALU usage required
            RegWrite = 1; // update register
              BytesToAccess = 0;
            // BytestoWrite = 0;
            branch = 0; // required to update control for branch inst
            jump = 0;
             MuxINCSelect = 0; // sequentially next PC
            // MuxMASelect = 1; // PC send to mem_add_reg in step1
             MemRead = false;
            MemWrite = false;
            MuxASelect = 0;  // rs1
            MuxBSelect = 0;  // no immediate
            MuxYSelect = 0;  // choose output of ALU in RZ
            MuxPCSelect = 1; // not ra
          
           
            break;
        case 19:          // R-type
            ALUOp = 1;    // ALU usage required
            RegWrite = 1; // update register
            BytesToAccess = 0;
            // BytestoWrite = 0;
            branch = 0; // required to update control for branch inst
            jump = 0;
            MuxASelect = 0;  // rs1
            MuxBSelect = 1;  //  imm value used in MuxB
            MuxYSelect = 0;  // choose output of ALU in RZ
            MuxPCSelect = 1; // not ra
             MemRead = false;
            MemWrite = false;
            MuxINCSelect = 0; // sequentially next PC
            // MuxMASelect = 1; // PC send to mem_add_reg in step1
            break;
        case 3:           // I-type (load-instructions)
            ALUOp = 1;    // ALU used to calculate effective address
            RegWrite = 1; // update register
            MemRead = true;
            MemWrite = false;
            switch (funct3)
            {
            case 0: // lb
                BytesToAccess = 1;
                break;
            case 1: // lh
                BytesToAccess = 2;
                break;
            case 2: // lw
                BytesToAccess = 4;
                break;
            default:
                throw runtime_error("\033[1;31mInvalid funct3\033[0m");
            }
            // BytestoWrite = 0;
            MuxINCSelect = 0; // sequentially next PC
            MuxASelect = 0;   // rs1
            MuxBSelect = 1;   // imm value used in MuxB
            MuxYSelect = 1;   // mem_data_reg value selected
            branch = 0;       // required to update control for branch inst
            jump = 0;         // required to update control for jump inst
            MuxPCSelect = 1;  // not ra
            // MuxMASelect = 1;   // PC send to mem_add_reg in step1
            break;

        case 103:           // I-type(jalr)
            ALUOp = 0;      // ALU not used, done in IAG
            MuxBSelect = 0; // don't-care
            MuxYSelect = 2; // ra given to MuxY
            BytesToAccess = 0;
            RegWrite = 1;     // update register
            MuxINCSelect = 1; // receive imm
            MuxASelect = 0;   // rs1
            branch = 0;       // required to update control for branch inst
            jump = 1;         // jump instruction
            MuxPCSelect = 0;  // ra input to MuxPC
            MemRead = false;
            MemWrite = false;
            // MuxMASelect = 1; // PC send to mem_add_reg in step1
            break;
        case 35:            // S-type
            ALUOp = 1;      // ALU used to calculate effective address
            MuxBSelect = 1; // imm value used in MuxB
            MuxYSelect = 0; // don't-care
            // BytestoRead = 0;
            if (funct3 == 0)
            { // sb
                BytesToAccess = 1;
            }
            else if (funct3 == 1)
            { // sh
                BytesToAccess = 2;
            }
            else if (funct3 == 2)
            { // sw
                BytesToAccess = 4;
            }
            else
            {
                throw invalid_argument("\033[1;31mInvalid funct3\033[0m");
            }
            RegWrite = 0;     // Register update not required
            MuxINCSelect = 0; // sequentially next PC
            MuxASelect = 0;   // rs1
            branch = 0;       // required to update control for branch inst
            jump = 0;
            MuxPCSelect = 1; // not ra
            MemRead = false;
            MemWrite = true;
            // MuxMASelect = 1;        //PC send to mem_add_reg in step1
            break;
        case 23: // U-type(auipc)
            ALUOp = 1;
            MuxBSelect = 1;
            MuxYSelect = 0; // choose output of ALU in RZ
            // BytestoRead = 0;
            // BytestoWrite = 0;
            BytesToAccess = 0;
            RegWrite = 1;
            MuxINCSelect = 0; // sequentially next PC
            MuxASelect = 1;   // PC as input1 of ALU
            MuxPCSelect = 1;  // not ra
            branch = 0;       // required to update control for branch inst
            jump = 0;
            MemWrite = false;
            MemRead = false;
            break;
            // MuxMASelect = 1;     // PC send to mem_add_reg in step1
        case 55: // U-type(lui)
            ALUOp = 1;
            MuxBSelect = 1;
            MuxYSelect = 0; // choose output of ALU in RZ
            // BytestoRead = 0;
            // BytestoWrite = 0;
            BytesToAccess = 0;
            RegWrite = 1;
            MuxINCSelect = 0; // sequentially next PC(4)
            MuxASelect = 0;   // rs1
            branch = 0;       // required to update control for branch inst
            jump = 0;
            MuxPCSelect = 1; // not ra
            MemRead = false;
            MemWrite = false;
            // MuxMASelect = 1;     // PC send to mem_add_reg in step1
            break;
        case 111:           // UJ-type(jal)
            ALUOp = 0;      // ALU not required, done in IAG
            MuxBSelect = 0; // don't-care
            MuxYSelect = 2; // ra given to MuxY
            BytesToAccess = 0;
            RegWrite = 1; // update register
            MuxINCSelect = 1;
            MuxASelect = 0; // rs1
            branch = 0;     // required to update control for branch inst
            jump = 1;
            MuxPCSelect = 1; // not ra
            MemRead = false;
            MemWrite = false;
            break;
        case 99:            // B type
            ALUOp = 1;      // ALU computes boolean for branch
            MuxBSelect = 0; // rs2 is required, imm is used in IAG
            MuxYSelect = 0; // RZ, but don't-care
            RegWrite = 0;   // do not update register
            BytesToAccess = 0;
            MuxINCSelect = 0; // to be updated after ALU
            MuxASelect = 0;   // rs1
            branch = 1;       // required to update control for branch inst
            jump = 0;
            MuxPCSelect = 1; // not ra
            MemRead = false;
            MemWrite = false;
            break;
        default:
            throw runtime_error("\033[1;31mInvalid opcode\033[0m");
        }
    }

    void decode(int IR, int PC)
    { 
        cout<<"Stage1: Fetch Instruction:  0x"<< hex << IR <<" from PC : 0x" <<PC <<endl;
        cout<<"Stage2: Decode Completed"<<endl;
        int code = IR;
        int temp = 0x0000007f;
        opcode = (code & temp); 
        if (opcode == 17)
        {
            terminate = true;
            return;
        }

        else if (opcode == 51)
        {
            vector<int> v(5);
            v = decodeR(code);
            imm = 0;
            rd = v[0];
            funct3 = v[1];
            rs1 = v[2];
            rs2 = v[3];
            funct7 = v[4];

            cout << "R type Instruction with"
                 << " "
                 << "rd:" << rd << " funct3:" << funct3 << " rs1:" << rs1 << " rs2:" << rs2 << " funct7:" << funct7 << endl;
            SignalGenerator();
            ALUcontrol = ALUControl();
            return;
        }

        else if (opcode == 19 || opcode == 3 || opcode == 103)
        {
            vector<int> v(4);
            v = decodeI(code);
            funct7 = 0;
            rd = v[0];
            funct3 = v[1];
            rs1 = v[2];
            imm = v[3];
            cout << "I type Instruction with"
                 << " "
                 << "rd:" << rd << " funct3:" << funct3 << " rs1:" << rs1 << " rs2:" << rs2 << " imm:" << imm << endl;
            SignalGenerator();
            ALUcontrol = ALUControl();
            return;
        }

        else if (opcode == 35)
        {
            vector<int> v(4);
            v = decodeS(code);
            funct7 = 0;
            rd = 0;
            funct3 = v[0];
            rs1 = v[1];
            rs2 = v[2];
            imm = v[3];
            cout << "S type Instruction with"
                 << " "
                 << "rd:" << rd << " funct3:" << funct3 << " rs1:" << rs1 << " rs2:" << rs2 << " imm:" << imm << endl;
            SignalGenerator();
            ALUcontrol = ALUControl();
            return;
        }

        else if (opcode == 99)
        {
            vector<int> v(4);
            v = decodeB(code);
            funct7 = 0;
            rd = 0;
            funct3 = v[0];
            rs1 = v[1];
            rs2 = v[2];
            imm = v[3];
            cout << "B type Instruction with"
                 << " "
                 << "rd:" << rd << " funct3:" << funct3 << " rs1:" << rs1 << " rs2:" << rs2 << " imm:" << imm << endl;
            SignalGenerator();
            ALUcontrol = ALUControl();
            return;
        }
        else if (opcode == 23 || opcode == 55)
        {
            funct3 = 0;
            funct7 = 0;
            rs1 = 0;
            rs2 = 0;
            vector<int> v(2);
            v = decodeU(code);
            rd = v[0];
            imm = v[1];
            cout << "U type Instruction with"
                 << " "
                 << "rd:" << rd << " funct3:" << funct3 << " rs1:" << rs1 << " rs2:" << rs2 << " imm:" << imm << endl;
            SignalGenerator();
            ALUcontrol = ALUControl();
            return;
        }

        else if (opcode == 111)
        {
            funct3 = 0;
            funct7 = 0;
            rs1 = 0;
            rs2 = 0;
            vector<int> v(2);
            v = decodeJ(code);
            rd = v[0];
            imm = v[1];
            cout << "J type Instruction with"
                 << " "
                 << "rd:" << rd << " funct3:" << funct3 << " rs1:" << rs1 << " rs2:" << rs2 << " imm:" << imm << endl;
            SignalGenerator();
            ALUcontrol = ALUControl();
            return;
        }
        else if ((opcode != 51) && (opcode != 19) && (opcode != 3) && (opcode != 103) && (opcode != 35) && (opcode != 99) && (opcode != 23) && (opcode != 55) && (opcode != 111))
        {
            cout << "Instruction not valid" << endl;
        }
    }

    vector<int> decodeR(int code)
    {
        vector<int> v;
        code = code >> 7;
        v.push_back((code & 0x1f)); // rd
        code = code >> 5;
        v.push_back((code & 0x7)); // funct3
        code = code >> 3;
        v.push_back((code & 0x1f)); // rs1;
        code = code >> 5;
        v.push_back((code & 0x1f)); // rs2;
        code = code >> 5;
        v.push_back((code & 0x7f)); // funct7
        return v;
    }

    vector<int> decodeI(int code)
    {
        vector<int> v;
        code = code >> 7;
        v.push_back((code & 0x1f)); // rd
        code = code >> 5;
        v.push_back((code & 0x7)); // funct3
        code = code >> 3;
        v.push_back((code & 0x1f)); // rs1;
        code = code >> 5;
        int var = ((code & 0x000007ff) | -(code & 0x00000800));
        v.push_back(var); // signed immediate;
        return v;
    }

    vector<int> decodeS(int code)
    {
        vector<int> v;
        code = code >> 7;
        int imm1 = (code & 0x0000001f);
        code = code >> 5;
        v.push_back((code & 0x7)); // funct3
        code = code >> 3;
        v.push_back((code & 0x1f)); // rs1;
        code = code >> 5;
        v.push_back((code & 0x1f)); // rs2;
        int imm2 = code >> 5;
        imm2 = imm2 << 5;
        imm2 += imm1;
        v.push_back(imm2);
        return v;
    }

    vector<int> decodeB(int code)
    {
        
        std::vector<int> v;
        int func3 = code & 0x000007000;
        func3 = func3 >> 12;
        v.push_back(func3); // funct3
        int r1 = code & 0x000F8000;
        r1 = r1 >> 15;
        v.push_back(r1); // rs1
        int r2 = code & 0x01F00000;
        r2 = r2 >> 20;
        v.push_back(r2); // rs2
        int temp = code >> 7;
        int temp11 = temp & 0x01; // imm[11]
        temp11 = temp11 << 11;
        int temp1 = code >> 8;
        temp1 = temp1 & 0x0F; // imm[4:1]
        temp1 = temp1 << 1;
        int temp5 = code >> 25;
        temp5 = temp5 & 0x03F; // imm[10:5]
        temp5 = temp5 << 5;
        int temp12 = code >> 31;
        temp12 = temp12 << 12;                         // imm[12]
        int immf = temp12 + temp11 + temp5 + temp1;    // finding final imm
        int im = (-(immf & 0x1000) | (immf & 0x0FFF)); // making it signed
        v.push_back(im);
        return v;
    }

    vector<int> decodeU(int code)
    {
        vector<int> v;
        code = code >> 7;
        v.push_back(code & 0x1f); // rd
        code = code >> 5;
        int var = ((code & 0x7ffff) | -(code & 0x80000));
        v.push_back(var); // signed immediate;
        return v;
    }

    vector<int> decodeJ(int code)
    {
        
        vector<int> v;
        code = code >> 7;
        v.push_back(code & 0x0000001f); // rd
        code = code >> 5;
        int imm19 = code;
        imm19 = imm19 << 12;
        imm19 = imm19 >> 11; // imm[19:12]
        code = code >> 8;
        int imm11 = code;
        imm11 = imm11 << 11;
        imm11 = imm11 >> 10; // imm11[11];
        code = code >> 1;
        int imm10 = code;
        imm10 = imm10 << 1; // imm[10:1];
        code = code >> 10;
        int imm20 = code;
        imm20 = imm20 << 19;
        imm20 = imm20 + imm19 + imm11 + imm10;
        v.push_back(imm20);
        return v;
    }

    int ALUControl()
    {
        if (opcode == 51 && funct3 == 0 && funct7 == 0)
           {
            cout<<"Operation is add "<<" "<<endl;
            return 0;
           }
        else if (opcode == 51 && funct3 == 7 && funct7 == 0)
            {  cout<<"Operation is and "<<" "<<endl;
                return 1;} // and
        else if (opcode == 51 && funct3 == 6 && funct7 == 0)
            {cout<<"Operation is or "<<" "<<endl;
            return 2;} // or
        else if (opcode == 51 && funct3 == 1 && funct7 == 0)
            {cout<<"Operation is sll "<<" "<<endl;
            return 3;} // sll
        else if (opcode == 51 && funct3 == 5 && funct7 == 0)
           {cout<<"Operation is srl "<<" "<<endl;
            return 4;} // srl
        else if (opcode == 51 && funct3 == 5 && funct7 == 32)
           {cout<<"Operation is sra "<<" "<<endl; return 6;} // sra
        else if (opcode == 51 && funct3 == 0 && funct7 == 32)
           {cout<<"Operation subtract "<<" "<<endl; return 7;} // sub
        else if (opcode == 51 && funct3 == 4 && funct7 == 0)
            {cout<<"Operation is xor "<<" "<<endl;
            return 8;} // xor
        else if (opcode == 19 && funct3 == 0 && funct7 == 0)
            {cout<<"Operation addi "<<" "<<endl; return 0;} // addi
        else if (opcode == 19 && funct3 == 7 && funct7 == 0)
            {cout<<"Operation andi "<<" "<<endl;return 1;} // andi
        else if (opcode == 19 && funct3 == 6 && funct7 == 0)
            {cout<<"Operation is ori "<<" "<<endl;return 2;} // ori
        else if (opcode == 3 && funct3 == 0 && funct7 == 0)
            {cout<<"Operation LoadByte "<<" "<<endl;return 0; }// lb
        else if (opcode == 3 && funct3 == 1 && funct7 == 0)
           { cout<<"Operation Load Half Word "<<" "<<endl;return 0;} // lh
        else if (opcode == 3 && funct3 == 2 && funct7 == 0)
            {cout<<"Operation Load Word "<<" "<<endl;return 0;} // lw
        else if (opcode == 103 && funct3 == 0 && funct7 == 0)
           { cout<<"Operation Load Word "<<" "<<endl;return 0;} // jalr
        else if (opcode == 35 && funct3 == 0 && funct7 == 0)
            {cout<<"Operation Store Byte "<<" "<<endl; return 0;} // sb
        else if (opcode == 35 && funct3 == 1 && funct7 == 0)
           {cout<<"Operation Store word "<<" "<<endl; return 0;} // sw
        else if (opcode == 35 && funct3 == 2 && funct7 == 0)
           {cout<<"Operation Store half word "<<" "<<endl; return 0;} // sh
        else if (opcode == 99 && funct3 == 0 && funct7 == 0)
            {cout<<"Operation BEQ "<<" "<<endl; return 13;} // beq
        else if (opcode == 99 && funct3 == 1 && funct7 == 0)
           {cout<<"Operation BNE "<<" "<<endl; return 14;} // bne
        else if (opcode == 99 && funct3 == 5 && funct7 == 0)
              {cout<<"Operation BGE "<<" "<<endl;return 15;} // bge
        else if (opcode == 99 && funct3 == 4 && funct7 == 0)
             {cout<<"Operation BLT "<<" "<<endl; return 16;} // blt
        else if (opcode == 23 && funct3 == 0 && funct7 == 0)
              {cout<<"Operation AUIPC "<<" "<<endl; return 12;} // auipc
        else if (opcode == 55 && funct3 == 0 && funct7 == 0)
            {cout<<"Operation LUI "<<" "<<endl;     return 12;} // lui
        else if (opcode == 111 && funct3 == 0 && funct7 == 0)
             {cout<<"Operation JAL "<<" "<<endl;    return 12;} // jal
        else
        {
            cout << "Instruction not valid" << endl; 
        }
    }
   
    void BranchUpdate(bool outputBool)
    {
        if (branch == 1 && jump == 1)
        {
            throw runtime_error("\033[1;31mInvalid control signal\033[0m");
        }
        else if (branch == 0 && jump == 0)
        {
            MuxINCSelect = 0;
        }
        else if (branch == 0 && jump == 1)
        {
            MuxINCSelect = 1;
        }
        else if (branch == 1 && outputBool == 1)
        {
            MuxINCSelect = 1;
        }
        else if (branch == 1 && outputBool == 0)
        {
            MuxINCSelect = 0;
        }
    }
};

