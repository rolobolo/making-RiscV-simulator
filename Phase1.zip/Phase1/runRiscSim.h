#include <bits/stdc++.h>
//simulator file containing all modules required for all stages
#include "myRegisters.h" // assuming Registers is a header file that contains 32 GP registers and IR
#include "MemAccess.h"   // assuming Memory is a header file that defines ProcessorMem class
#include "Controls.h"    // assuming ControlCircuit is a header file that defines ControlModule class
#include "InstAddress.h" // assuming IAG is a header file that defines IAG class
#include "myALU.h"       // assuming ALU is a header file that defines ALU class
#include "TempReg.h"     // assuming TempRegisters is a header file that defines TempRegisters class

using namespace std;

const int MAX_SIGNED_NUM = 0x7fffffff;  // required to check for errors like when memory out of bounds etc
const int MIN_SIGNED_NUM = -0x80000000;
const int MAX_UNSIGNED_NUM = 0xffffffff;
const int MIN_UNSIGNED_NUM = 0x00000000;

Registers registers;                   // create an instance of the Registers class
ProcessorMem memory;       // create an instance of the ProcessorMem class
ControlModule control_module;          // create an instance of the ControlModule class
ALU ALUmodule;         // create an instance of the ALU class
IAG IAGmodule; // create an instance of the IAG class
TempRegisters buffer;                        // create an instance of the TempRegisters class

// Mux used 
int MuxAout = 0; // first input to ALU
int MuxBout = 0; // second input to ALU , op2select
int MuxYout = 0; // output of Result Select Mux

int MuxB(int MuxB_select)
{
  int MuxBout = 0;
  if (MuxB_select == 0)
  {
    MuxBout = registers.ReadGlobalReg(control_module.rs2);
  }
  else if (MuxB_select == 1)
  {
    MuxBout = control_module.imm;
  }
  return MuxBout;
}

int MuxA(int MuxA_select)
{
  int MuxAout = 0;
  if (MuxA_select == 0)
  {
    MuxAout = registers.ReadGlobalReg(control_module.rs1);
  }
  else if (MuxA_select == 1)
  {
    MuxAout = IAGmodule.PC;
  }
  return MuxAout;
}

int MuxY(int MuxY_select)
{
  int MuxYout = 0;
  if (MuxY_select == 0)
  {
    MuxYout = buffer.getRZ();
  }
  else if (MuxY_select == 1)
  {
    MuxYout = memory.mem_data_reg;
  }
  else if (MuxY_select == 2)
  {
    MuxYout = IAGmodule.PC_temp;
  }
  return MuxYout;
}

// Stage functions
void fetch(int stage)
{ //Control signals update
  // fectching Instructions 
  //Loading instructions to memory and then loading them from memory to registers and giving value to registers
  //In this PC+4 calculated and stored 
  control_module.StateUpdate(stage);
  memory.Load(IAGmodule.PC);                  
  registers.WriteReg(memory.mem_data_reg, control_module.IRwrite);
  IAGmodule.PCtemp();   
  // cout<<"Stage 1: Fetch "<<endl;                         
}

void decode(int stage)
{
  //update the control signals
  //second step: decoding the instructions and then updating the control signals accordingly 
  //cout<<"Stage 2: Decode Completed"<<endl;
  control_module.StateUpdate(stage);
  control_module.decode(registers.ReadReg(), IAGmodule.PC); 
  //cout << "Stage 3: Execution " << endl;
  
  if (control_module.terminate == 1)
  {
    return;   // if not updated next stage else read registers and 
  }
  buffer.setRA(registers.ReadGlobalReg(control_module.rs1)); // Value of rs1 stored in RA then sent to InstAddress as input
  buffer.setRM(registers.ReadGlobalReg(control_module.rs2)); // Value of rs2 stored in RM
  IAGmodule.PCset(buffer.getRA(), control_module.MuxPCSelect); //choosing PC
  IAGmodule.SetOffset(control_module.imm);               // Immediate value which was calculated before sent to InstAddress as imm
  // Loading the register values

  MuxAout = MuxA(control_module.MuxASelect);
  MuxBout = MuxB(control_module.MuxBSelect);
 
}

void execute(int stage)
{
  
  control_module.StateUpdate(stage); // updating control signals
  ALUmodule.ALUexecute(control_module.ALUOp, control_module.ALUcontrol, MuxAout, MuxBout); //executing ALU operation using the inputs to ALU based on the control signals , output stored in RZ

  buffer.setRZ(ALUmodule.output32);

  control_module.BranchUpdate(ALUmodule.outputBool);  // Updates the branching status based on the output of ALU operation
  IAGmodule.PCUpdate(control_module.MuxINCSelect); // Updating the program counter
  
}

void mem(int stage)
{
  //cout<<"Stage 4: Memory Access"<<endl;
  control_module.StateUpdate(stage); //updates the current state
  memory.Access(control_module.MemRead, control_module.MemWrite, buffer.getRZ(), control_module.BytesToAccess, buffer.getRM()); // deciding whether memory to be read or not , whether to  be written or not , RZ in mem_add_reg, RM updates based on the memory access
   
}

void write_back(int stage)
{
  //cout<<"Stage 5: Write Back "<<endl;
  control_module.StateUpdate(stage);
  buffer.setRY(MuxY(control_module.MuxYSelect)); //RY is the output of MuxY(ResultSelect) which will be selected according to control signals
  registers.WriteGlobalReg(control_module.rd, control_module.RegWrite, buffer.getRY());  //writing back to registers
  
}

void RunRiscSim()
{
   // initialize the clock variable to 1
  int clock = 1;
  // create a loop that runs indefinitely
  while (1)
  {
    // print the current cycle number
    cout << "\nCycle " << clock << "\n";
// set the stage variable to 0 and call the fetch function
    int stage = 0;
    fetch(stage);
    
// set the stage variable to 1 and call the decode function
    stage = 1;
    decode(stage);
    
    if (control_module.terminate == 1)
    {
      return;
    }

    stage = 2;
    execute(stage);
    

    stage = 3;
    mem(stage);
   
    stage = 4;
    write_back(stage);
    
 // increment the clock variable
    clock++;
  }
}
