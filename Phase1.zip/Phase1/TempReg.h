#include <bits/stdc++.h>
using namespace std;
// keeping record of temporary registers
class TempRegisters
{

private:
    int RA;
    int RZ;
    int RM;
    int RY;

public:
    TempRegisters()
    {
        RA = 0;
        RZ = 0;
        RM = 0;
        RY = 0;
    }
    int getRA()
    {
        return RA;
    }
    int getRZ()
    {
        return RZ;
    }
    int getRM()
    {
        return RM;
    }
    int getRY()
    {
        return RY;
    }
    void setRA(int val)  // storing registers value basically PC +4
    {
        RA = val;
    }
    void setRZ(int val)
    {
        RZ = val;
    }
    void setRM(int val)
    {
        RM = val;
    }
    void setRY(int val)
    {
        RY = val;
    }
};
