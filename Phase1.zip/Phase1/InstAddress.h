
// InstAddress
#include <bits/stdc++.h>
using namespace std;
//Input is control signals and accordingly PC is updated or calculated
class IAG
{

public:
    int PC;  // current PC
    int PC_temp; //  to hold the temporary value of PC i.e. PC+4
    int IAGimm;  // immediate value for branch instructions 
    static const int MAX_SIGNED_NUM = 0x7fffffff;
    static const int MIN_SIGNED_NUM = -0x80000000;
    static const int MAX_UNSIGNED_NUM = 0xffffffff;
    static const int MIN_UNSIGNED_NUM = 0x00000000;
    static const int MAX_PC = 0x7ffffffc;

    IAG() // constructor
    {
        PC = 0;
        PC_temp = 0;
        IAGimm = 0;
    }

    int ReadPC()
    {

        return PC;
    }
    void WritePC(int WriteVal, bool writePC) // Writing to PC
    {
        if (writePC == true)
        {
            PC = WriteVal;
        }
    }
     void PCset(int RA, int MuxPCselect)  // Used for Jalr 
    {
        if (MuxPCselect == 0)
        {
            PC = RA;
        }
    }

    void PCtemp()
    {
        PC_temp = PC + 4;  // storing PC for next instruction first step .This supplied to Result Select before write back
    }

   
  
    void PCUpdate(int MuxINCSelect) //  getting the mux value from control based on the comparison operations performed by the ALU , decides whether to jump or to not
    {
        if (MuxINCSelect == 0) // mux==0 next instruction
        {
            PC = PC+ 4;
        }
        else if (MuxINCSelect == 1) // jump to PC+ immediate
        {
            PC = PC+ IAGimm;
            if (PC > MAX_PC)
            {
                cerr << "Address is not in range of data segment" << endl;  // out of bounds
                exit(1);
            }
        }
    }

      void SetOffset(int boffset) 
    {
        IAGimm = boffset; //offset stored
    }

};
